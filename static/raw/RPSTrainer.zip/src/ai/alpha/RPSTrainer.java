package ai.alpha;

import java.util.Arrays;
import java.util.Random;

public class RPSTrainer {

    public void train(RPSPlayer player1,  RPSPlayer player2, int iterations) {
        for (int i = 0; i < iterations; i++) {
            double[] strategy1 = player1.getStrategy();
            int action1 = player1.getAction(strategy1);

            double[] strategy2 = player2.getStrategy();
            int action2 = player2.getAction(strategy2);

            player1.updateRegret(action1, action2);
            player2.updateRegret(action2, action1);
        }
    }

    public static void main(String[] args) {
        RPSPlayer player1 = new RPSPlayer();
        RPSPlayer player2 = new RPSPlayer();

        RPSTrainer trainer = new RPSTrainer();
        trainer.train(player1, player2, 10000000);
        System.out.println(Arrays.toString(player1.getAverageStrategy()));
        System.out.println(Arrays.toString(player2.getAverageStrategy()));
    }
}
